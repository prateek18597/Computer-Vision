Jupyter Notebook ImageInterpolation.ipynb contains code and report for this assignment.
"Interpolated Images" folder contains Intepolated images of size 1000X1000X3.
"OriginalImages" folder contains original images of size 500X500X3.
