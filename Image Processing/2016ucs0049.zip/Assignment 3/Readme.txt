Open "2016ucs0049.ipynb" in jupyter notebook.
Jupyter notebook contains PSNR values of Demosaiced images with respect to original image and PSNR values of Demosaiced images after applying bilateral filter over it with respect to original image.
"Original" folder contains Original Images used.
"Raw" folder contains Raw Images( Bayer Filter image).
"Predicted" folder contains Demosaiced images generated.
"Bilateral" folder contains Demosaiced images after applying bilateral filter on them.
50 Images are used in this Assignment.
